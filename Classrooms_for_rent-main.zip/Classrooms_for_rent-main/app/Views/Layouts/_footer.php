    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <span class="copyright">&copy; 2022</span>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>